<h1 align="center">TERRORIST - Private DDOS Panel</h1>
<h5 align="center">(Programming Language - Python/Nodejs/Go/C)</h5>

                                  ;:::::;
                                ;::::;  :;                        ________________________________
                              ;:::::'    :;                     /\                               |
                             ;:::::;      ;.                    \_| Hello Skidies! Welcome to my |
                            ,:::::' ▄▄▄▄▄▄ ;           OOO       |            new panel          |
                            ::::::;        ;          OOOOO      |                               |
                            ;:::::;        ;         OOOOOOOO    |   ____________________________|
                           ,;::::::;      ;'        / OOOOOOO     \_/____________________________/
                         ;:::::::::`. ,,,;.        /  / DOOOOOO
                       .';:::::::::::::::::;,     /  /     DOOOO        [  TERRORIST V.2  ]
                      ,::::::;::::::;;;;::::;,   /  /        DOOO
                     ;`::::::`'::::::;;;::::: ,#/  /          DOOO
                     :`:::::::`;::::::;;::: ;::#  /            DOOO
                     ::`:::::::`;:::::::: ;::::# /              DOO
                     `:`:::::::`;:::::: ;::::::#/               DOO
                      :::`:::::::`;; ;:::::::::##                OO
                      ::::`:::::::`;::::::::;:::#                OO
                      `:::::`::::::::::::;'`:;::#                O
                        `:::::`::::::::;' /  / `:#
                         ::::::`:::::;'  /  /   `#")
                         
<p align="center">[ ! ] Please Don't Attack Gonvernment websites without the owners consent [ ! ]</p>

# 📰 Terrorist Infomation

<img align="right" width=210px alt="PNG" src="https://media.discordapp.net/attachments/1126029184871976970/1198629189851553913/terrorist.png?ex=65bf996c&is=65ad246c&hm=c56518670b02b5dfaa7aa4cd870a86b498390b2b7513833bfd3a0c3a222808ec&=&format=png&width=500&height=597" />


-   🗒️ | Tool has L4/L7/AA: [ **20** ] **Methods**
-   🌟 | **SpamSMS** included
-   👀 | Tools: **IP** Lookup
-   ⚡ | Attack: You should by a **VPS** or paid multiple **IDE** for better attack
-   🔐 | Privacy: Take your **own risk** when starting DDOS XD
-   🗓️ | Project started since **2020**
-   🔗 | Support: **[Join now](https://t.me/daxgstress), [Discord](https://dsc.gg/daxg)**
-   ⛏️ | Environment: **Javascript, Python, Golang, Perl**
<hr>

# 📖 Setup

Setup Error visit our [Discord](https://dsc.gg/daxg)

## ! Please read the 'license' and the 'privacy' tab before downloading
**Clone and Install Script**

```shell script
git clone https://github.com/D4XG/terrorist.git
cd terrorist-main
python setup.py
python terrorist.py
```
Account / Password can be change in terrorist.py
```shell script
Account: DAXG
Password: dsc.gg/daxg
```
Setup process may took up to 5 minutes depend on your Network
BE PATIENT

# ⚡ Update

Use '**update**' in panel to update to the lastest version!
